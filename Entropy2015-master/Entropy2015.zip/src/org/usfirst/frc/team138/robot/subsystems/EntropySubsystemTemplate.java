package org.usfirst.frc.team138.robot.subsystems;

public interface EntropySubsystemTemplate {
	boolean initialize();
	void cleanup();
	String getFeedback();
}
